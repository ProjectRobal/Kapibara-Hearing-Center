import glob
import librosa as wav
import soundfile as sf
import numpy as np


files=glob.glob('./wavs/unsettling*.wav')

for f in files:
    print(f)
    
    audio,sample_rate=wav.load(f,sr=16000,mono=True)

    audio=audio*2

    sf.write(f,audio,sample_rate,'PCM_16')